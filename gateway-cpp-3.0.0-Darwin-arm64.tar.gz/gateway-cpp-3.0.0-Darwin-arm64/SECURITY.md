# 安全审查记录（gateway-cpp）

针对"外部程序 A → DLL（不可信 JSON 输入）→ 落盘"与守护进程对上游的网络通信，做了一轮安全专项审查。
下表为已发现并**已修复**的问题；末尾列出残留事项与使用约束。

## 已修复

| # | 级别 | 问题 | 修复 | 回归用例 |
|---|---|---|---|---|
| 1 | 高 | **深嵌套 JSON 触发递归解析栈溢出**，崩溃整个宿主进程（栈溢出 try/catch 捕获不到） | `parse_resources` 在 nlohmann 解析前**预扫嵌套深度**，超过 128 层直接拒绝 | `security_test` ①：20 万层 `[` 被拒、进程存活 |
| 2 | 中 | **TLS 证书校验默认关闭**（`insecure_=true`）→ 上游通信可被 MITM 窃取/篡改（含 clientSecret / AK-SK） | 默认改为**校验证书**；自签内网需经 `network.insecure: true` 显式开启；已贯通 Collector/Uploader/Refresher/Auth 各 HTTP 调用点 | 守护 TU 编译验证 |
| 3 | 中 | **输入大小无上限** → 内存耗尽 DoS | `parse_resources` 限制单次输入 ≤ 64MB | `security_test` ②：65MB 被拒 |
| 4 | 低 | **文件名清洗不足**：控制字符/NUL 未过滤、允许纯点名、无限长（路径分隔符已处理，穿越基本被挡） | `sanitize` 去控制字符/NUL、禁纯点名、限长 64；`/`、`\` 仍替换为 `-` | `security_test` ③：`../../../tmp/evil` 产物仍夹在 out_dir 内、文件名无分隔符 |
| 5 | 低 | **`std::stoi` 在超长 LID+GID 抛 `out_of_range`** | `lid_gid_to_binary` 内 try/catch，异常即按无法编码处理 | `security_test` ④：4+50 位地址不崩溃 |
| 6 | 低 | **`std::regex` 对超长地址超线性回溯(ReDoS)** | 地址校验前加 64 字符长度上限 | 同 ④ 路径 |

## 审查确认无问题

- **SQL 注入**：不适用——字典为本地 JSON 文件（`FileStore`），无数据库、无 SQL。
- **C ABI 异常逃逸**：4 个 `gw_*` 均为 function-try-block，兜 `std::exception` 与 `...`，绝不跨 `extern "C"` 抛出（UB）。
- **内存所有权**：返回 `char*` 全部 `malloc`/`gw_free` 配对；`*out=nullptr` 先置位；`gw_open` 失败 `delete`。
- **并发**：字典快照 `atomic_load/store`，`gw_reload` 失败保留旧快照；`g_last_error` 为 `thread_local`。
- **JSON 输出注入**：`usage.ip`、city/zone 等经 `nlohmann::dump`（`error_handler=replace`）转义，无注入；非 UTF-8 不抛。

## 残留事项与使用约束（非代码缺陷）

- **配置含明文密钥**：`application.yaml` 的 `clientSecret`、AK/SK 为明文（与 Java 现状一致）。生产应改为环境变量/密钥管理注入，勿入库。
- **`network.insecure: true` 仅限自签内网**：对接公网/生产平台务必设为 `false`。
- **C ABI 误用**：调用方须保证句柄只 `gw_close` 一次、返回串只 `gw_free` 一次（C 接口固有约束）。
- **`next_sequence` 非并发安全**：多线程/多进程向同一目录写同企业同秒文件存在 TOCTOU；并发落盘应分目录或串行化。
- **字节级一致性**：`Decimal` 用 `long double` 近似（已隔离，待黄金对拍校准）；`networkCapacityIp`/`serverType` 按对接文档修正、与旧 Java 有意分叉（见 `tools/upstream_json_schema.md`）。

## 运行测试

```bash
ctest --test-dir build -R "security|capi_file|golden_encoder" --output-on-failure
```
