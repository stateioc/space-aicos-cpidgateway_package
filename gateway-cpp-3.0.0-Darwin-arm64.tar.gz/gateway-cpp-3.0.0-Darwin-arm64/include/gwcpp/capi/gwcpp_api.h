/* ===========================================================================
 * gwcpp_api.h —— CPURL 编码器的 C ABI（供 DLL/so/dylib 对外发布）。
 *
 * 为什么是 C 接口：C++ 类/STL 跨动态库边界在不同编译器/运行时下不兼容；
 * 纯 C 接口可被 C/C++/C#(P/Invoke)/Python(ctypes)/Java(JNA)/Go(cgo) 等直接调用。
 *
 * 线程安全：gw_ctx 内部持有原子字典快照。
 *   - gw_encode_* 可多线程并发调用（各自取一份只读快照）。
 *   - gw_reload 原子换快照，不阻塞正在进行的编码。
 *
 * 内存约定：所有返回的 char* 由本库 malloc，调用方必须用 gw_free() 释放。
 * =========================================================================== */
#ifndef GWCPP_CAPI_H
#define GWCPP_CAPI_H

#if defined(_WIN32)
#  if defined(GWCPP_BUILDING_DLL)
#    define GWCPP_API __declspec(dllexport)
#  elif defined(GWCPP_STATIC)
#    define GWCPP_API
#  else
#    define GWCPP_API __declspec(dllimport)
#  endif
#else
#  define GWCPP_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* 不透明句柄：一份已加载的字典 + 编码上下文 */
typedef struct gw_ctx gw_ctx;

/* 库版本字符串（静态常量，勿释放） */
GWCPP_API const char* gw_version(void);

/* 打开：从本地 JSON 字典文件加载内存快照。失败返回 NULL。 */
GWCPP_API gw_ctx* gw_open(const char* dict_path);

/* 重新加载字典（原子换快照，热更新）。成功返回 0。 */
GWCPP_API int gw_reload(gw_ctx* ctx, const char* dict_path);

/* 编码一条/一组 StandardResource。
 *   resource_json : 单个对象或对象数组（与采集响应里 data 元素同构）
 *   is_total      : 1=全量(K1)，0=可用(K2)
 *   out_json      : 出参，malloc 的 JSON：{"success":bool,"message":str,"cpurls":[...]}
 * 返回 0 表示调用完成（业务成败看 out_json.success）；非 0 为参数/内部错误。
 * *out_json 需用 gw_free() 释放。 */
GWCPP_API int gw_encode_json(gw_ctx* ctx, const char* resource_json, int is_total, char** out_json);

/* 编码并落盘：校验→编码→按 (city,zone) 分组，一次调用汇总成【一个】文件。
 *   resource_json : 单个对象/对象数组/整包 {data:[...]}（采集数据，同 gw_encode_json）
 *   is_total      : 1=全量(K1)，0=可用(K2)
 *   is_monitor    : 1=监测数据，0=调度数据（写入每个数组元素的 isMonitor 字段）
 *   out_dir       : 输出目录（不存在则尝试创建）
 *   out_result_json : 出参，malloc 的 JSON：
 *       {"success":bool,"message":str,"path":str|null,"record_count":N,
 *        "groups":[{enterprise,city,zone,count,usage_count}|{...,error}|{...,skipped}]}
 * 文件名：{enterprise}-CPURL-DATA-{yyyyMMddHHmmss}{NNNN}.data
 *        （NNNN 为同目录同秒内的 4 位序号 0001 起，避免重名/覆盖）
 * 文件内容：JSON 数组，每个 (city,zone) 组一个元素：
 *        [ {enterprise,city,zone,isMonitor,cpurls:[...],usage:[{ip,cpuUsage,memUsage},...]}, ... ]
 * 至少一组成功才写文件；某组失败记入 groups[].error，不影响其它组。
 * 返回 0 表示调用完成。*out_result_json 用 gw_free 释放。 */
GWCPP_API int gw_encode_to_file(gw_ctx* ctx, const char* resource_json,
                                int is_total, int is_monitor,
                                const char* out_dir, char** out_result_json);

/* 取最近一次错误描述（线程局部，静态缓冲，勿释放）。 */
GWCPP_API const char* gw_last_error(void);

/* 释放本库返回的字符串。 */
GWCPP_API void gw_free(char* s);

/* 关闭并释放上下文。 */
GWCPP_API void gw_close(gw_ctx* ctx);

#ifdef __cplusplus
}
#endif

#endif /* GWCPP_CAPI_H */
