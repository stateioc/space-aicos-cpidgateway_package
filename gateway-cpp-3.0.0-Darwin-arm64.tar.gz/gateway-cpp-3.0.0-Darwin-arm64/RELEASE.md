# gateway-cpp 发布包导引

算力标识编码网关（C++）。部署到服务器后，别的系统通过**动态库（DLL/.so/.dylib）**调用，
把采集数据(JSON) 编码成算力标识文件。

> **交付方式：二进制分发（推荐，保护源码）。**
> 你在自己的构建机上 `./scripts/package.sh --strip` 编一次，产出的 `.tar.gz`
> **只含编译好的动态库 + 头文件 + 文档 + 工具，不含 `src/` 源码**，直接交付第三方即可。
> 动态库与目标服务器 **OS/架构相关**，所以构建机要和目标服务器同系统（同 glibc）。

---

## 一、二进制包里有什么（`scripts/package.sh` 的 CPack 产物）

| 目录/文件 | 内容 |
|---|---|
| `lib/libgwcpp.{so,dylib}` / `bin/gwcpp.dll` | **编译好的对外动态库**（仅导出 8 个 `gw_*` 接口，`--strip` 后内部符号已去除） |
| `bin/gateway` | 字典初始化可执行工具 |
| `include/gwcpp/capi/gwcpp_api.h` | C 调用方头文件 |
| `examples/` | 调用示例：`c_client.c`（纯C）、`gw_gateway.hpp`（C++ RAII封装）、`cpp_app.cpp`（C++完整示例） |
| `tools/seed_import.py` | 字典初始化脚本（从上游拉取生成 `dict.json`） |
| `cnf/application.yaml` | `gateway` 初始化工具的配置 |
| `samples/` | 测试用样例 `dict.sample.json` + `input.sample.json` |
| **`docs/DEPLOY.md`** | **部署与路径配置**（部署文档） |
| **`docs/INTEGRATION.md`** | **对接使用手册**（接口/输入输出/多语言示例） |
| **`docs/cpp_client_guide.md`** | **C++ 调用完整手册**（RAII/CMake/错误/并发/热更新） |
| `tools/upstream_json_schema.md` | 输入 JSON 字段契约 |
| `README.md` `SECURITY.md` | 总览 / 安全说明 |

> 注意：包内**没有 `src/`、`CMakeLists.txt`、构建脚本**——这些是你本地构建用的，不随二进制交付。
> `examples/*.cpp` 是“怎么调用 DLL”的示例，**不含编码算法**，可放心交付。

---

## 二、在构建机上编译并打二进制包（一次）

依赖：CMake≥3.20、C++20 编译器；系统库 `curl/openssl/zlib`（**编码 DLL 本身零运行时第三方依赖**，
这些仅 `gateway` 初始化工具用）。`nlohmann-json`/`yaml-cpp` 由 CMake 自动拉取（或用 vcpkg）。

```bash
# Debian/Ubuntu 装依赖
sudo apt install cmake g++ libcurl4-openssl-dev libssl-dev zlib1g-dev

# 一键编译 + 测试 + 打二进制包（--strip 去内部符号），产出 build/gateway-cpp-<ver>-<os>-<arch>.tar.gz
./scripts/package.sh --strip
```
构建机要与目标服务器同 OS/架构（同 glibc）；交付该 `.tar.gz` 即可，无需给源码。详见 `docs/BUILD.md`。

---

## 三、部署 + 初始化字典

```bash
# 解压打包产物到部署目录
tar xzf build/gateway-cpp-*.tar.gz -C /opt/gateway-cpp --strip-components=1

# 生成 dict.json（二选一）
#   A) 联网：改 cnf/application.yaml 的 heartbeat 凭据后
GW_DICT_FILE=/opt/gateway-cpp/dict.json /opt/gateway-cpp/bin/gateway /opt/gateway-cpp/cnf/application.yaml
#   B) 脚本：
export GW_CLIENT_ID=xxx GW_CLIENT_SECRET=yyy
python3 /opt/gateway-cpp/tools/seed_import.py --base https://<上游>:60006 --enterprise 20067 --out /opt/gateway-cpp/dict.json
```
完整部署/路径配置见 **`docs/DEPLOY.md`**。

---

## 四、别的系统怎么调用

- **C++**：拷 `examples/gw_gateway.hpp`，`gw::Gateway gw("dict.json"); gw.encode_to_file(json, true, false, "/data/cpurl");`
  完整手册 → **`docs/cpp_client_guide.md`**。
- **C / C# / Python / Java**：见 **`docs/INTEGRATION.md`**（含各语言示例、错误码、输入输出格式）。

最小自测（构建后）：
```bash
./build/cpp_app samples/dict.sample.json samples/input.sample.json /tmp/out   # 应打印 success:true 并落盘 .data
```

---

## 五、要点速记

- 编码 DLL **零运行时第三方依赖**、线程安全、按需调用、无需常驻进程。
- 字典是一个本地 **`dict.json`**（不用数据库）；运行期可 `gw_reload` 热更新。
- 输出目录由调用方传参、可配；文件名固定 `{enterprise}-CPURL-DATA-{yyyyMMddHHmmss}{NNNN}.data`。
- 企业/行业/城市/芯片/CPU 不在字典内的资源会被校验拒绝（不生成脏标识）。
