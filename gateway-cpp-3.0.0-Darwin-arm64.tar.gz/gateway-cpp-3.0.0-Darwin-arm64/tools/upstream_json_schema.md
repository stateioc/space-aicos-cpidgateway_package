# 上游传入 JSON 契约（gw_encode_json / gw_encode_to_file 的输入）

依据《企业侧标识网关部署对接文档 v5.4》整理。来源是云管平台
`GET /north/cpcResource?isMonitor={true|false}` 的响应；外部程序 A 把它原样传给网关 DLL。

DLL 接受三种形态（`parse_resources` 自动识别）：
1. 整包：`{ "code":1, "message":"成功", "success":true, "data":[ <资源>, ... ] }`
2. 资源数组：`[ <资源>, ... ]`
3. 单个资源对象：`{ "summary":{...}, "servers":[...] }`

## 资源对象结构

```jsonc
{
  "summary": {
    "enterprise": "20088",          // String(5) 企业编码
    "industry":   "tc",             // String(2) 行业编码
    "city":       "5101",           // String(4) 城市编码（名/码皆可，查字典归一）
    "zone":       "SC-Xiyun108",    // String(30) 可用区编码（企业映射表）
    "resourceCatalog": ["FIN","FGE"],   // Array  FGE通算/FIN智算/FSU超算
    "serviceCatalog":  ["云服务器"],     // Array  参考算力标识附录
    "chipCapacity": [ { "chipType":"T4", "chipNum":16 } ],
    "networkCapacityIp":   0,        // Integer Mbps  ← 注意字段名是 Ip（编码进 N00 段）
    "networkCapacityIb":   0,        // Integer Mbps  → N01 段
    "networkCapacityRoce": 0,        // Integer Mbps  → N10 段
    "storageArch": "DT"             // DT分布式 / CT集中式
  },
  "servers": [
    {
      "status":   "selling",        // selled/selling
      "cpuType":  "Intel Xeon Gold 6240",
      "serverType": "FSU",          // 非必填，FGE/FIN/FSU；在此(ZoneServer)层级，下传 used/free
      "used": [
        {
          "serverCatalog": "Y1899", // 必须 Y 开头、长度 5
          "cpuCores": 4, "memoryCapacity": 8,            // 核 / GB
          "blockStorage":185,  "blockStorageUnit":"TB",  // PB/TB/GB
          "objectStorage":192, "objectStorageUnit":"TB",
          "fileStorage":713,   "fileStorageUnit":"TB",
          "amount": 5,                                    // 同规格台数
          "usage": [ { "ip":"...", "cpuUsage":33.6, "memUsage":66.8 } ],  // 监测用，编码忽略
          "chips": [
            { "networkCatalog":"IPV4",      // IPV4/IPV6/MAC/LID+GID
              "networkAddress":"10.104.12.45",
              "chipCatalog":"CPU",          // 芯片类型（参考附录 chip_catalog）
              "chipType":"Intel Xeon Gold 6240",  // 芯片型号（查 chip 字典）
              "chipSn":"73614" }            // 输入会被编码器用组内序号覆盖
          ]
        }
      ],
      "free": [ { /* 同 used 结构 */ } ]
    }
  ]
}
```

## C++ 端解析要点（与 Java 原域模型的偏差，已在 Models 修正）

| 文档真实字段 | 说明 | C++ 处理 |
|---|---|---|
| `networkCapacityIp` | IP/TCP 带宽（Java 旧模型误用 `networkCapacityTcp`） | 读 `networkCapacityIp`，回退 `networkCapacityTcp` |
| `serverType` 在 ZoneServer 层 | 与 used/free 同级，非必填 | 解析后**下传**到每个 used/free Server，供 FSU 判定 |
| 整包 `{...,data:[...]}` | 原始响应外层 | `parse_resources` 自动解包 |
| `usage`(ip/cpuUsage/memUsage) | 机器负载 | **不参与编码**，但 `gw_encode_to_file` 会按 ip 去重聚合，写入输出文件顶层 `usage` 数组 |
| 输入 `chipSn` | 占位 | 忽略（编码器用组内序号覆盖） |

> 字段“是否必填/长度”以对接文档 v5.4 表格为准；编码前 `detector` 会校验
> 资源类型/服务类型/芯片型号/CPU 型号是否都在本地字典（dict.json）内。

## 决策（已确认）：按标准正确，不复刻 Java 旧行为

这两处修正使 C++ 比 Java 原实现**更符合对接文档**，因此与现网 Java 输出会**有意分叉**：

| 情形 | Java 旧实现 | C++（本项目，标准正确） |
|---|---|---|
| `networkCapacityIp > 0` | 读不到 → N00 段恒 `0000000` | N00 段为真实带宽值 |
| 存在 `serverType="FSU"` 的超算 | `Server.serverType` 恒 null → 误判为智算(FIN) | 正确归类超算，进 FSU 资源码/算力桶 |
| `enterprise`/`industry`/`city` 不在字典 | 回退原值、照编出脏 CPURL | **硬拒绝**该组（groups[].error），不生成脏标识（字典缺该类目时跳过校验）|

**对 P0 黄金对拍的影响**：当输入资源含 IP 带宽 / FSU 服务器 / 非法企业·行业·城市时，
C++ 与 Java 的输出会不同（前两者影响 CPURL 段，后者 C++ 直接拒绝而 Java 仍编出）——
这是**预期差异**，对拍时应以“标准正确”为基准，不可当作移植缺陷修回去。其余字段仍要求逐字节一致。
