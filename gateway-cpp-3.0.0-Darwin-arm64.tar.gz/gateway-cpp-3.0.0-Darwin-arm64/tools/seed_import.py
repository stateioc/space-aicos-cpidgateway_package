#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从上游 /api/sms 字典端点拉取数据，写入本地 JSON 字典文件 (dict.json)。
目标服务器禁用 SQLite，故用纯文件；该文件供 C++ DLL gw_open() 读取。

凭据从环境变量读取，绝不写入仓库或日志。

用法：
  export GW_CLIENT_ID=xxxx
  export GW_CLIENT_SECRET=yyyy
  python3 tools/seed_import.py \
      --base https://10.20.13.74:60006 \
      --enterprise 20067 \
      --out ./dict.json \
      [--insecure]   # 自签证书内网默认开启

端点：
  GET {base}/api/sms/v1/chips/list
  GET {base}/api/sms/v1/dictionaries?pid=0
  GET {base}/api/sms/v1/zones/enter/{enterprise}

输出 JSON 结构（与 C++ FileStore 一致）：
  {"schema_version":1,
   "dictionary":[{"category","code","name"}],
   "chips":[{"name","code","capacity","category","isCpu"}],
   "zones":[{"codeKey","nameKey","zone"}],
   "meta":{"seed_source": base}}
"""
import argparse
import json
import os
import re
import ssl
import sys
import urllib.request
import urllib.error


def tiny_name(s: str) -> str:
    """trim -> 去所有空白 -> 小写（与编码链路 tinyName 一致）"""
    if s is None:
        return ""
    return re.sub(r"\s+", "", s.strip()).lower()


def fetch(base: str, path: str, client_id: str, client_secret: str, insecure: bool):
    """GET {base}/api/sms{path}?page=0&rows=999999，解析 {success,data}。失败返回 None。"""
    url = base.rstrip("/") + "/api/sms" + path
    url += ("&" if "?" in path else "?") + "page=0&rows=999999"
    req = urllib.request.Request(url, method="GET")
    req.add_header("X-CLIENT-ID", client_id)
    req.add_header("X-CLIENT-SECRET", client_secret)
    req.add_header("Content-Type", "application/json")
    ctx = ssl.create_default_context()
    if insecure:
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
    try:
        with urllib.request.urlopen(req, timeout=60, context=ctx) as resp:
            body = resp.read().decode("utf-8")
    except urllib.error.URLError as e:
        print(f"[ERR ] fetch {path} 传输失败: {e}", file=sys.stderr)
        return None
    try:
        j = json.loads(body)
    except json.JSONDecodeError as e:
        print(f"[ERR ] fetch {path} JSON 解析失败: {e}; body[:200]={body[:200]}", file=sys.stderr)
        return None
    if not j.get("success", False):
        print(f"[ERR ] fetch {path} 业务失败: {j.get('message')}", file=sys.stderr)
        return None
    return j.get("data")


def flatten_dict(nodes, out):
    """递归拍平字典树：父节点 value -> category，子节点 value/name 入表"""
    if not isinstance(nodes, list):
        return
    for node in nodes:
        parent_value = node.get("value", "")
        children = node.get("children")
        if isinstance(children, list) and children:
            for child in children:
                out.append({"category": parent_value,
                            "code": child.get("value", ""),
                            "name": child.get("name", "")})
            flatten_dict(children, out)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--base", default=os.getenv("GW_BASE", "https://10.20.13.74:60006"))
    ap.add_argument("--enterprise", required=True, help="企业编码，用于 /v1/zones/enter/{ent}")
    ap.add_argument("--out", default="./dict.json")
    ap.add_argument("--insecure", action="store_true", default=True)
    args = ap.parse_args()

    client_id = os.getenv("GW_CLIENT_ID")
    client_secret = os.getenv("GW_CLIENT_SECRET")
    if not client_id or not client_secret:
        print("请先设置 GW_CLIENT_ID / GW_CLIENT_SECRET 环境变量", file=sys.stderr)
        sys.exit(2)

    chips = fetch(args.base, "/v1/chips/list", client_id, client_secret, args.insecure)
    dict_tree = fetch(args.base, "/v1/dictionaries?pid=0", client_id, client_secret, args.insecure)
    enter_zone = fetch(args.base, f"/v1/zones/enter/{args.enterprise}", client_id, client_secret, args.insecure)

    if not isinstance(dict_tree, list) or not isinstance(chips, list):
        print("字典/芯片拉取失败，不生成文件", file=sys.stderr)
        sys.exit(1)

    out = {"schema_version": 1, "dictionary": [], "chips": [], "zones": [], "meta": {"seed_source": args.base}}

    # 字典
    flatten_dict(dict_tree, out["dictionary"])
    cats = sorted({d["category"] for d in out["dictionary"]})
    print(f"[ OK ] dictionary: {len(out['dictionary'])} 行，category={cats}")

    # 芯片
    n_cpu = 0
    for c in chips:
        name = c.get("name", "")
        cap = c.get("capacity")
        cap = "1" if cap is None else (cap if isinstance(cap, str) else str(cap))
        category = c.get("category", "")
        is_cpu = (category == "00001")
        n_cpu += 1 if is_cpu else 0
        out["chips"].append({"name": name, "code": c.get("code", ""),
                             "capacity": cap, "category": category, "isCpu": is_cpu})
    print(f"[ OK ] chip: {len(out['chips'])} 行（其中 CPU {n_cpu}）")

    # 企业可用区
    if isinstance(enter_zone, list):
        for z in enter_zone:
            ent, city = z.get("enterprise", ""), z.get("cityCode", "")
            ext, zname, zcode = z.get("extZoneCode", ""), z.get("zoneName", ""), z.get("zoneCode", "")
            if not ent or not city or not zcode:
                continue
            out["zones"].append({"codeKey": ent + city + (ext or ""),
                                 "nameKey": ent + city + (zname or ""), "zone": zcode})
        print(f"[ OK ] enter_zone: {len(out['zones'])} 行")
    else:
        print("[WARN] enter_zone 缺失，字典将不含可用区映射", file=sys.stderr)

    # 原子写：临时文件 + 替换
    tmp = args.out + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, indent=2)
    os.replace(tmp, args.out)
    print(f"\n全部写入成功：{args.out}")


if __name__ == "__main__":
    main()
