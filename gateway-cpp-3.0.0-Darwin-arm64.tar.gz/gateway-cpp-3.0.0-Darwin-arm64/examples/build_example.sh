#!/usr/bin/env bash
# ===========================================================================
# 一键编译 C++ 对接用例：把 examples/cpp_app.cpp 链接到 lib/libgwcpp.so。
#
# 在解压后的发布包里运行（包根或 examples/ 下均可）：
#   ./examples/build_example.sh
#
# 产物：examples/cpp_app；试运行：
#   ./examples/cpp_app samples/dict.sample.json samples/input.sample.json /tmp/cpurl_out
#   ls /tmp/cpurl_out        # 生成的 *-CPURL-DATA-*.data 文件
#
# rpath 用 $ORIGIN/../lib，可执行文件无论拷到哪都能自动找到同包的 libgwcpp.so。
# ===========================================================================
set -euo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"   # examples/
ROOT="$(cd "$HERE/.." && pwd)"                          # 包根
CXX="${CXX:-g++}"

"$CXX" -std=c++17 "$HERE/cpp_app.cpp" \
  -I"$HERE" -I"$ROOT/include" \
  -L"$ROOT/lib" -lgwcpp -Wl,-rpath,'$ORIGIN/../lib' \
  -o "$HERE/cpp_app"

echo "已编译: $HERE/cpp_app"
echo "试运行: $HERE/cpp_app $ROOT/samples/dict.sample.json $ROOT/samples/input.sample.json /tmp/cpurl_out"
