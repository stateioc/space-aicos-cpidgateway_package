// ===========================================================================
// cpp_app.cpp —— 外部 C++ 系统调用网关 DLL 的完整示例（零额外依赖，用 RAII 封装）。
//
// 编译（Linux/macOS）：
//   g++ -std=c++17 examples/cpp_app.cpp -Iexamples -Iinclude \
//       -L<libdir> -lgwcpp -Wl,-rpath,<libdir> -o cpp_app
// 运行：
//   ./cpp_app <dict.json> <input.json> <out_dir>
//
// 说明：本示例不依赖任何 JSON 库——直接打印网关返回的结果 JSON 字符串。
// 实际项目里用你自己的 JSON 库解析其中的 success / path / groups（见 docs/cpp_client_guide.md）。
// ===========================================================================
#include "gw_gateway.hpp"     // RAII 封装（examples/gw_gateway.hpp）

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

static std::string read_file(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) throw std::runtime_error("无法读取文件: " + path);
    std::ostringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

int main(int argc, char** argv) {
    if (argc < 4) {
        std::cerr << "用法: " << argv[0] << " <dict.json> <input.json> <out_dir>\n";
        return 2;
    }
    try {
        std::cout << "网关版本: " << gw::Gateway::version() << "\n";

        // 1) 进程内打开一次字典（可长期复用、可多线程并发调用 encode_*）
        gw::Gateway gw(argv[1]);

        // 2) 读入采集数据（上游 /north/cpcResource 整包 / 资源数组 / 单对象均可）
        std::string input = read_file(argv[2]);

        // 3) 编码并落盘：全量(K1) + 监测数据
        std::string result = gw.encode_to_file(input, /*is_total=*/true, /*is_monitor=*/true, argv[3]);
        std::cout << "落盘结果(JSON):\n" << result << "\n";

        // 也可不落盘、直接拿 CPURL 串：
        // std::string cpurls = gw.encode_json(input, /*is_total=*/true);

        return 0;
    } catch (const gw::GatewayError& e) {
        std::cerr << "网关错误 (code=" << e.code() << "): " << e.what() << "\n";
        return 1;
    } catch (const std::exception& e) {
        std::cerr << "错误: " << e.what() << "\n";
        return 1;
    }
}
