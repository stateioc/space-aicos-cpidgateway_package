// ===========================================================================
// gw_gateway.hpp —— gwcpp C ABI 的 C++ RAII 薄封装（header-only，零额外依赖）。
//
// 外部 C++ 系统可直接拷贝本文件使用：句柄随对象生命周期自动 open/close，
// 返回字符串自动 gw_free，错误以异常抛出。要求 C++11 及以上。
//
// 用法：
//   gw::Gateway gw("/opt/gateway-cpp/dict.json");          // 进程内建一次、长期复用、可并发
//   std::string result = gw.encode_to_file(json, true, false, "/data/cpurl");
//   // result 是 {"success":...,"path":...,"groups":[...]} 的 JSON，用你自己的 JSON 库解析
// ===========================================================================
#pragma once
#include "gwcpp/capi/gwcpp_api.h"

#include <stdexcept>
#include <string>
#include <utility>

namespace gw {

// 调用失败时抛出；code 为 C 接口返回码（见手册错误码表），what() 含 gw_last_error 详情。
class GatewayError : public std::runtime_error {
public:
    GatewayError(int code, std::string msg) : std::runtime_error(std::move(msg)), code_(code) {}
    int code() const noexcept { return code_; }
private:
    int code_;
};

class Gateway {
public:
    // 加载字典文件，失败抛 GatewayError。
    explicit Gateway(const std::string& dict_path) {
        ctx_ = gw_open(dict_path.c_str());
        if (!ctx_) throw GatewayError(-1, std::string("gw_open failed: ") + gw_last_error());
    }
    ~Gateway() { if (ctx_) gw_close(ctx_); }

    Gateway(const Gateway&) = delete;
    Gateway& operator=(const Gateway&) = delete;
    Gateway(Gateway&& o) noexcept : ctx_(o.ctx_) { o.ctx_ = nullptr; }
    Gateway& operator=(Gateway&& o) noexcept {
        if (this != &o) { if (ctx_) gw_close(ctx_); ctx_ = o.ctx_; o.ctx_ = nullptr; }
        return *this;
    }

    // 热加载新字典（原子换，不阻塞正在进行的编码）。失败抛 GatewayError。
    void reload(const std::string& dict_path) {
        int rc = gw_reload(ctx_, dict_path.c_str());
        if (rc != 0) throw GatewayError(rc, std::string("gw_reload rc=") + std::to_string(rc) + ": " + gw_last_error());
    }

    // 编码并落盘：返回结果回执 JSON（含 path / record_count / groups）。
    //   is_total=true 全量(K1) / false 可用(K2)；is_monitor=true 监测 / false 调度。
    std::string encode_to_file(const std::string& resource_json, bool is_total,
                               bool is_monitor, const std::string& out_dir) {
        char* out = nullptr;
        int rc = gw_encode_to_file(ctx_, resource_json.c_str(), is_total ? 1 : 0,
                                   is_monitor ? 1 : 0, out_dir.c_str(), &out);
        FreeGuard g(out);
        if (rc != 0) throw GatewayError(rc, std::string("gw_encode_to_file rc=") + std::to_string(rc) + ": " + gw_last_error());
        return out ? std::string(out) : std::string();
    }

    // 编码但不落盘：返回 {"success":...,"cpurls":[...]} JSON。
    std::string encode_json(const std::string& resource_json, bool is_total) {
        char* out = nullptr;
        int rc = gw_encode_json(ctx_, resource_json.c_str(), is_total ? 1 : 0, &out);
        FreeGuard g(out);
        if (rc != 0) throw GatewayError(rc, std::string("gw_encode_json rc=") + std::to_string(rc) + ": " + gw_last_error());
        return out ? std::string(out) : std::string();
    }

    static std::string version() { return gw_version(); }

private:
    // 确保 gw_free 被调用（即使中途抛异常）
    struct FreeGuard {
        char* p;
        explicit FreeGuard(char* x) : p(x) {}
        ~FreeGuard() { if (p) gw_free(p); }
        FreeGuard(const FreeGuard&) = delete;
        FreeGuard& operator=(const FreeGuard&) = delete;
    };

    gw_ctx* ctx_ = nullptr;
};

} // namespace gw
