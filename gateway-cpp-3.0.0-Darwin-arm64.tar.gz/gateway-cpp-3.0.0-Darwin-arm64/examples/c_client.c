/* 纯 C 调用方示例：加载 dict.json → 编码一条资源 → 打印 CPURL。
 *
 * 编译（macOS，示例）：
 *   cc examples/c_client.c -Iinclude -L. -lgwcpp -o c_client
 *   DYLD_LIBRARY_PATH=. ./c_client ./dict.json
 */
#include "gwcpp/capi/gwcpp_api.h"
#include <stdio.h>
#include <stdlib.h>

/* 整包响应形态（/north/cpcResource），含 networkCapacityIp 与 ZoneServer 级 serverType */
static const char* kResource =
"{\"code\":1,\"message\":\"成功\",\"success\":true,\"data\":[{"
"  \"summary\": {"
"    \"enterprise\":\"20067\",\"industry\":\"cp\",\"city\":\"5101\",\"zone\":\"cn-chengdu-1\","
"    \"storageArch\":\"DT\",\"resourceCatalog\":[\"FIN\"],\"serviceCatalog\":[],"
"    \"networkCapacityIp\":5000,\"networkCapacityIb\":0,\"networkCapacityRoce\":0,"
"    \"chipCapacity\":[{\"chipType\":\"A100\",\"chipNum\":1}]"
"  },"
"  \"servers\":[{"
"    \"cpuType\":\"xeon\",\"serverType\":\"FIN\","
"    \"free\":[{"
"      \"serverCatalog\":\"Y0001\","
"      \"blockStorage\":1024,\"blockStorageUnit\":\"GB\","
"      \"objectStorage\":0,\"objectStorageUnit\":\"GB\","
"      \"fileStorage\":0,\"fileStorageUnit\":\"GB\","
"      \"memoryCapacity\":256,\"cpuCores\":64,\"amount\":2,"
"      \"usage\":[{\"ip\":\"10.0.0.1\",\"cpuUsage\":33.6,\"memUsage\":66.8}],"
"      \"chips\":[{\"networkCatalog\":\"IPV4\",\"networkAddress\":\"10.0.0.1\",\"chipCatalog\":\"GPU\",\"chipType\":\"A100\"}]"
"    }]"
"  }]"
"}]}";

int main(int argc, char** argv) {
    const char* db = argc > 1 ? argv[1] : "./dict.json";
    printf("lib version: %s\n", gw_version());

    gw_ctx* ctx = gw_open(db);
    if (!ctx) { fprintf(stderr, "gw_open failed: %s\n", gw_last_error()); return 1; }

    /* 1) 直接拿到 CPURL（JSON 返回） */
    char* out = NULL;
    int rc = gw_encode_json(ctx, kResource, 1 /*total*/, &out);
    if (rc != 0) {
        fprintf(stderr, "gw_encode_json rc=%d: %s\n", rc, gw_last_error());
        gw_close(ctx);
        return 1;
    }
    printf("encode result:\n%s\n", out);
    gw_free(out);

    /* 2) 编码并落盘：一次调用一个文件，内容为各(city,zone)组的数组
       文件名 {enterprise}-CPURL-DATA-{yyyyMMddHHmmss}{NNNN}.data */
    char* fres = NULL;
    rc = gw_encode_to_file(ctx, kResource, 1 /*total=K1*/, 0 /*schedule*/, "/tmp/cpurl_out", &fres);
    if (rc != 0) {
        fprintf(stderr, "gw_encode_to_file rc=%d: %s\n", rc, gw_last_error());
        gw_close(ctx);
        return 1;
    }
    printf("\nfile result:\n%s\n", fres);
    gw_free(fres);

    gw_close(ctx);
    return 0;
}
