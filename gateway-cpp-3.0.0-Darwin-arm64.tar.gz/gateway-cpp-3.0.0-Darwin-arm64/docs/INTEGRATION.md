# gateway-cpp 外部系统对接说明

本文档面向**调用方系统**（外部程序 A），说明如何用 gateway-cpp 动态库把采集到的资源数据
（JSON）生成算力标识（CPURL）文件。

> 网关是**被动**的：你的系统负责采集数据并调用本库；本库负责**校验 → 编码 → 落盘**。
> 不需要常驻进程，按需调用即可。

---

## 1. 你需要准备的三样东西

| # | 物料 | 说明 | 如何获得 |
|---|---|---|---|
| 1 | 动态库 | `libgwcpp.so`(Linux) / `libgwcpp.dylib`(macOS) / `gwcpp.dll`(Windows) | `cmake --build build --target gwcpp_shared` |
| 2 | 头文件 | `gwcpp_api.h`（C 调用方需要；其它语言按下文绑定） | `include/gwcpp/capi/gwcpp_api.h` |
| 3 | 字典文件 | `dict.json`（本地 JSON 文件，编码查表用） | 见下「字典初始化」 |

动态库**零运行时第三方依赖**（字典是本地 JSON 文件、nlohmann 头文件内联、编码不联网），分发轻量；
目标服务器禁用 SQLite 也能跑。

### 字典库初始化（部署时一次性）

`dict.json` 提供企业/城市/芯片/CPU/可用区的编码映射。两种方式任选其一：

```bash
# 方式 A：联网从上游拉取（需配置 cnf/application.yaml 的 heartbeat 凭据）
./gateway cnf/application.yaml          # store.mode=online 时拉取并写入 dict.json

# 方式 B：离线种子（python，不依赖网关可执行）
export GW_CLIENT_ID=...  GW_CLIENT_SECRET=...
python3 tools/seed_import.py --base https://<上游>:60006 --enterprise 20067 --out ./dict.json
```

> 字典可定期更新；运行期可用 `gw_reload()` 热加载新 `dict.json`，不中断编码。

---

## 2. 调用时序

```
gw_open(dict.json)                      // 1) 进程启动时打开一次，得到句柄 ctx（可复用、可并发）
  └─ 循环：gw_encode_to_file(ctx, json, is_total, is_monitor, out_dir, &result)
            └─ 解析 result（拿到落盘文件路径 / 逐组成败）
            └─ gw_free(result)        // 释放返回的字符串
gw_close(ctx)                         // 进程退出时关闭
```

- `ctx` **线程安全**：可在多线程中并发调用 `gw_encode_*`。
- 句柄建议**进程级复用**（打开字典有成本），不要每次调用都 open/close。

---

## 3. C ABI 接口

| 函数 | 作用 | 返回 |
|---|---|---|
| `const char* gw_version(void)` | 版本串（静态，勿释放） | 字符串 |
| `gw_ctx* gw_open(const char* dict_db_path)` | 加载字典，返回句柄 | 句柄 / `NULL`(失败) |
| `int gw_reload(gw_ctx*, const char* dict_db_path)` | 热加载新字典（原子换） | `0` 成功 |
| `int gw_encode_json(gw_ctx*, const char* json, int is_total, char** out)` | 编码，**结果以 JSON 返回**（不落盘） | 见错误码 |
| `int gw_encode_to_file(gw_ctx*, const char* json, int is_total, int is_monitor, const char* out_dir, char** out)` | 编码并**落盘文件** | 见错误码 |
| `const char* gw_last_error(void)` | 最近错误描述（线程局部，勿释放） | 字符串 |
| `void gw_free(char* s)` | 释放本库返回的字符串 | — |
| `void gw_close(gw_ctx*)` | 释放句柄 | — |

**内存约定**：`gw_encode_*` 通过出参返回的 `char*` 由本库分配，调用方**必须 `gw_free()`**。

**参数**：
- `is_total`：`1`=全量(K1)，`0`=可用(K2)。两类是**独立两次调用**（要两份就调两次）。
- `is_monitor`：`1`=监测数据，`0`=调度数据 → 写入文件每条记录的 `isMonitor` 字段。
- `out_dir`：输出目录，不存在会尝试创建。

**返回错误码**（`gw_encode_*` / `gw_reload`）：

| 码 | 含义 |
|---|---|
| `0` | 调用完成（**业务成败再看返回 JSON 的 `success`**） |
| `1` | 参数为空（句柄/json/out_dir 为 NULL） |
| `2` | 字典快照为空（dict.json 未加载/为空） |
| `3` | 输入 JSON 解析失败（语法错 / 过大 >64MB / 嵌套过深 >128 层） |
| `4` | 内存分配失败 |
| `5` | 文件写入失败（`gw_encode_to_file`） |
| `9` | 内部异常（详情见 `gw_last_error()`） |

> 即使返回 `0`，也要检查返回 JSON 的 `success` 与 `groups[].error`：某个 (city,zone) 组可能因
> 城市/芯片/CPU 不在字典里而单独失败，但不影响其它组。

---

## 4. 输入 JSON 格式

接受三种形态（自动识别）：
1. **整包响应**：`{ "code":1, "success":true, "data":[ <资源>, ... ] }`（即上游 `/north/cpcResource` 原样响应）
2. 资源数组：`[ <资源>, ... ]`
3. 单个资源对象：`{ "summary":{...}, "servers":[...] }`

资源对象结构、各字段含义（企业/城市/可用区/资源类型/服务器规格/芯片/`usage` 等），
以及与对接文档 v5.4 的对应关系，详见 **[`tools/upstream_json_schema.md`](../tools/upstream_json_schema.md)**。最小示例：

```json
{
  "summary": {
    "enterprise": "20067", "industry": "cp", "city": "5101", "zone": "cn-chengdu-1",
    "resourceCatalog": ["FIN"], "serviceCatalog": ["云服务器"],
    "chipCapacity": [{ "chipType": "A100", "chipNum": 1 }],
    "networkCapacityIp": 0, "networkCapacityIb": 0, "networkCapacityRoce": 0,
    "storageArch": "DT"
  },
  "servers": [{
    "cpuType": "Intel Xeon Gold 6240", "serverType": "FIN",
    "free": [{
      "serverCatalog": "Y0001", "cpuCores": 64, "memoryCapacity": 256, "amount": 2,
      "blockStorage": 1024, "blockStorageUnit": "GB",
      "objectStorage": 0, "objectStorageUnit": "GB",
      "fileStorage": 0, "fileStorageUnit": "GB",
      "usage": [{ "ip": "10.0.0.1", "cpuUsage": 33.6, "memUsage": 66.8 }],
      "chips": [{ "networkCatalog": "IPV4", "networkAddress": "10.0.0.1",
                  "chipCatalog": "GPU", "chipType": "A100" }]
    }]
  }]
}
```

**约束（务必满足，否则该组校验失败 → groups[].error，不生成脏 CPURL）**：
- `enterprise`、`industry`、`city` 必须在字典内（编码或名称命中；字典缺该类目时跳过校验）；
- `chipType`（芯片型号）、`cpuType`（CPU 型号）必须在芯片字典内；
- `resourceCatalog` / `serviceCatalog` 须为合法资源/服务类型；
- `serverCatalog` 必须以 `Y` 开头且长度 5。

---

## 5. 输出文件

**一次调用 → 一个文件**（按 (city,zone) 聚合成数组）。

- **文件名**：`{enterprise}-CPURL-DATA-{yyyyMMddHHmmss}{NNNN}.data`
  - `{enterprise}`：取输入第一条资源的企业号；
  - `{NNNN}`：同目录同秒 4 位序号（`0001` 起，避免重名/覆盖）。
- **文件内容**：JSON 数组，每个 (city,zone) 组一个元素：

```json
[
  {
    "enterprise": "20067", "city": "5101", "zone": "cn-chengdu-1", "isMonitor": false,
    "cpurls": [ "20067cp5101cn-chengdu-1K1/...", "..." ],
    "usage":  [ { "ip": "10.0.0.1", "cpuUsage": 33.6, "memUsage": 66.8 } ]
  }
]
```

- `cpurls`：该 (city,zone) 下所有算力标识串；
- `usage`：该 (city,zone) 下各机器负载，按**原始 ip 去重聚合**（不参与编码，仅透出）。

**调用返回的 JSON**（`out_result_json`，与文件不同——这是调用结果回执）：

```json
{
  "success": true,
  "message": "ok=3 failed=0",
  "path": "/data/out/20067-CPURL-DATA-202606040817230001.data",
  "record_count": 3,
  "groups": [
    { "enterprise":"20067", "city":"5101", "zone":"cn-chengdu-1", "count":2, "usage_count":1 },
    { "enterprise":"20067", "city":"1101", "zone":"cn-beijing-1", "error":"未知城市: 1101" }
  ]
}
```

---

## 6. 各语言调用示例

> 所有字符串均为 **UTF-8**（JSON 含中文）。注意各语言默认编码，按下文显式指定 UTF-8。
>
> **C++ 调用方完整手册**（RAII 封装、CMake 接入、错误处理、并发、热更新、动态加载）
> → **[`cpp_client_guide.md`](cpp_client_guide.md)**，配套可直接拷用的
> `examples/gw_gateway.hpp` 与 `examples/cpp_app.cpp`。

### C / C++（最小示例；C++ 推荐用上面的 RAII 封装）
```c
#include "gwcpp_api.h"
#include <stdio.h>

gw_ctx* ctx = gw_open("dict.json");
if (!ctx) { fprintf(stderr, "open: %s\n", gw_last_error()); return 1; }

char* res = NULL;
int rc = gw_encode_to_file(ctx, resource_json, 1 /*K1*/, 0 /*schedule*/, "/data/out", &res);
if (rc != 0) { fprintf(stderr, "rc=%d %s\n", rc, gw_last_error()); }
else         { printf("%s\n", res); }   // 解析 res.path / res.groups
gw_free(res);
gw_close(ctx);
```
链接：`cc app.c -I<include> -L<libdir> -lgwcpp`，运行时确保动态库可被找到
（Linux `LD_LIBRARY_PATH` / macOS `DYLD_LIBRARY_PATH` / Windows 与 exe 同目录）。

### C#（.NET，P/Invoke）
```csharp
using System;
using System.Runtime.InteropServices;

static class Gw {
    const string LIB = "gwcpp"; // gwcpp.dll / libgwcpp.so
    [DllImport(LIB, CallingConvention = CallingConvention.Cdecl)]
    public static extern IntPtr gw_open([MarshalAs(UnmanagedType.LPUTF8Str)] string dictDbPath);
    [DllImport(LIB, CallingConvention = CallingConvention.Cdecl)]
    public static extern int gw_encode_to_file(IntPtr ctx,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string json, int isTotal, int isMonitor,
        [MarshalAs(UnmanagedType.LPUTF8Str)] string outDir, out IntPtr result);
    [DllImport(LIB, CallingConvention = CallingConvention.Cdecl)]
    public static extern void gw_free(IntPtr s);
    [DllImport(LIB, CallingConvention = CallingConvention.Cdecl)]
    public static extern void gw_close(IntPtr ctx);
    [DllImport(LIB, CallingConvention = CallingConvention.Cdecl)]
    public static extern IntPtr gw_last_error();
}

var ctx = Gw.gw_open("dict.json");
if (ctx == IntPtr.Zero) throw new Exception(Marshal.PtrToStringUTF8(Gw.gw_last_error()));
int rc = Gw.gw_encode_to_file(ctx, json, 1, 0, "/data/out", out IntPtr res);
string result = Marshal.PtrToStringUTF8(res);   // 复制出托管字符串
Gw.gw_free(res);                                 // 再释放本库内存
Gw.gw_close(ctx);
```

### Python（ctypes）
```python
import ctypes, json

lib = ctypes.CDLL("./libgwcpp.dylib")   # Linux: ./libgwcpp.so  Windows: ./gwcpp.dll
lib.gw_open.restype = ctypes.c_void_p
lib.gw_open.argtypes = [ctypes.c_char_p]
lib.gw_encode_to_file.restype = ctypes.c_int
lib.gw_encode_to_file.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int,
                                  ctypes.c_int, ctypes.c_char_p, ctypes.POINTER(ctypes.c_void_p)]
lib.gw_free.argtypes = [ctypes.c_void_p]
lib.gw_close.argtypes = [ctypes.c_void_p]
lib.gw_last_error.restype = ctypes.c_char_p

ctx = lib.gw_open(b"dict.json")
if not ctx:
    raise RuntimeError(lib.gw_last_error().decode())

out = ctypes.c_void_p()
rc = lib.gw_encode_to_file(ctx, resource_json.encode("utf-8"), 1, 0,
                           b"/data/out", ctypes.byref(out))
result = ctypes.cast(out, ctypes.c_char_p).value.decode("utf-8")
lib.gw_free(out)
lib.gw_close(ctx)

r = json.loads(result)
print(r["success"], r["path"], r["groups"])
```

### Java（JNA）
```java
import com.sun.jna.*;
import com.sun.jna.ptr.PointerByReference;

public interface Gw extends Library {
    // 启动加 -Djna.encoding=UTF-8，保证中文 JSON 以 UTF-8 编组
    Gw I = Native.load("gwcpp", Gw.class);
    Pointer gw_open(String dictDbPath);
    int gw_encode_to_file(Pointer ctx, String json, int isTotal, int isMonitor,
                          String outDir, PointerByReference out);
    void gw_free(Pointer s);
    void gw_close(Pointer ctx);
    String gw_last_error();
}

Pointer ctx = Gw.I.gw_open("dict.json");
if (ctx == null) throw new RuntimeException(Gw.I.gw_last_error());
PointerByReference out = new PointerByReference();
int rc = Gw.I.gw_encode_to_file(ctx, json, 1, 0, "/data/out", out);
String result = out.getValue().getString(0, "UTF-8");
Gw.I.gw_free(out.getValue());
Gw.I.gw_close(ctx);
```

---

## 7. 运维与注意事项

- **句柄复用**：进程内 `gw_open` 一次、长期持有；多线程并发 `gw_encode_*` 安全。
- **字典更新**：换了新 `dict.json` 后调 `gw_reload()` 热加载，正在进行的编码不受影响。
- **K1/K2**：全量与可用是两次调用；若都写到同一目录同一秒，靠文件名 `{NNNN}` 序号区分、不会覆盖。
- **并发落盘**：`{NNNN}` 序号非并发安全（TOCTOU）。多线程/多进程同时写**同一目录**时，请分目录或自行串行化。
- **失败隔离**：单个 (city,zone) 组失败（如未知城市）记入 `groups[].error`，其余照常生成；`success=false` 仅表示"有组失败"。
- **安全**：库已内置不可信输入防护（JSON 大小/深度上限、文件名清洗）；详见 [`SECURITY.md`](../SECURITY.md)。
- **字典与编码一致性**：`dict.json` 应与上游字典保持同步，否则编码出的 CPURL 可能被监测平台拒（资源/芯片类型校验不过）。

---

## 8. 最小自检

部署后可用自带示例验证库与字典链路：
```bash
cmake --build build --target c_client
./build/c_client dict.json          # 应打印 encode result 与 file result(JSON)
```
更完整的端到端用例见 `test/capi_file_test.cpp`。
