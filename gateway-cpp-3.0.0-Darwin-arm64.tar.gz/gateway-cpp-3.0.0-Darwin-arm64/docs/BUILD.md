# gateway-cpp 编译与打包

面向**构建/发布人员**。最终产物：动态库 `libgwcpp.*`（对外编码 DLL）+ `gateway`（字典初始化）+ 头文件/配置/工具/文档，打成一个可部署压缩包。

---

## 1. 依赖

| 类别 | 组件 | 说明 |
|---|---|---|
| 工具链 | CMake ≥ 3.20、C++20 编译器（gcc 11+/clang 14+/MSVC 2022） | — |
| 系统库 | curl、openssl、zlib | 纯编码 DLL **不需要**它们（零运行时第三方依赖）；仅采集/上报/字典初始化用 |
| 取头库 | nlohmann-json、yaml-cpp | CMake `FetchContent` 自动拉取（**需网络**），或用 vcpkg。编码 DLL 仅 nlohmann（头文件内联） |

> 字典是本地 **JSON 文件**（不用 SQLite）；编码 DLL 因此零运行时第三方依赖。

安装系统库：
```bash
# macOS
brew install cmake curl openssl zlib
# Debian/Ubuntu
sudo apt install cmake g++ libcurl4-openssl-dev libssl-dev zlib1g-dev
# CentOS/RHEL
sudo yum install cmake gcc-c++ libcurl-devel openssl-devel zlib-devel
```

---

## 2. 编译

```bash
cd gateway-cpp
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

产物（在 `build/`）：

| 产物 | 说明 |
|---|---|
| `libgwcpp.so` / `libgwcpp.dylib` / `gwcpp.dll` | **对外编码动态库（主交付物）**，零运行时第三方依赖 |
| `gateway` | 字典初始化可执行（拉/校验 dict.json） |
| `c_client` | 纯 C 调用示例 |
| `gwcpp_*_tests` | 测试可执行 |

测试：
```bash
ctest --test-dir build --output-on-failure   # golden_encoder / capi_file / security
```

---

## 3. 打包（一键）

```bash
./scripts/package.sh                 # Release 编译 + 测试 + 生成压缩包
./scripts/package.sh --skip-tests    # 跳过测试
```

产出：`build/gateway-cpp-<版本>-<系统>-<架构>.tar.gz`（Windows 为 `.zip`）。

包内布局：
```
gateway-cpp-3.0.0-<os>-<arch>/
├── lib/        libgwcpp.so/.dylib   （Windows: 导入库 gwcpp.lib）
├── bin/        gateway              （Windows: gwcpp.dll 也在此）
├── include/gwcpp/capi/gwcpp_api.h   对外 C 头文件
├── cnf/        application.yaml
├── tools/      seed_import.py、upstream_json_schema.md
├── docs/       INTEGRATION.md、BUILD.md …
└── README.md   SECURITY.md
```

> 等价手动方式：`cmake --build build -j && (cd build && cpack)`；
> 或安装到指定前缀：`cmake --install build --prefix /opt/gateway-cpp`。

---

## 4. vcpkg（离线/可控依赖，可选）

无外网或要锁定依赖版本时，用 vcpkg 提供 nlohmann-json/yaml-cpp（`vcpkg.json` 已声明）：
```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release \
  -DCMAKE_TOOLCHAIN_FILE=$VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake
cmake --build build -j
./scripts/package.sh -DCMAKE_TOOLCHAIN_FILE=$VCPKG_ROOT/scripts/buildsystems/vcpkg.cmake
```

---

## 5. Windows（MSVC）

```bat
cmake -S . -B build -G "Visual Studio 17 2022" -A x64 ^
  -DCMAKE_TOOLCHAIN_FILE=%VCPKG_ROOT%\scripts\buildsystems\vcpkg.cmake
cmake --build build --config Release
cd build && cpack -G ZIP
```
- 产出 `gwcpp.dll` + 导入库 `gwcpp.lib`；`gateway.exe`。
- 平台移植已处理：`inet_pton`(IPv4 手解析免 WSAStartup)、`ws2_32` 自动链接、C ABI `__declspec` 导出宏。
- **静态链接调用方**：包含 `gwcpp_api.h` 前定义 `GWCPP_STATIC`，避免 `dllimport`。

---

## 6. 只要"编码 DLL"最小产物？

外部系统只需编码能力时，单独构建动态库目标即可（**零运行时第三方依赖**）：
```bash
cmake --build build --target gwcpp_shared
# → build/libgwcpp.*  +  include/gwcpp/capi/gwcpp_api.h  +  一个 dict.json
```
配合 `dict.json`（见 `docs/INTEGRATION.md` 的字典初始化）即可对接，无需 curl/openssl/zlib/yaml。

---

## 7. 常见问题

- **FetchContent 拉取失败**：无外网导致。改用 vcpkg（第 4 节），或预置 nlohmann-json/yaml-cpp 后用 `find_package`。
- **找不到 curl/openssl/zlib**：装对应 `-dev`/`-devel` 包（第 1 节）。注意编码 DLL 本身不需要它们。
- **运行期找不到动态库**：Linux 设 `LD_LIBRARY_PATH`、macOS 设 `DYLD_LIBRARY_PATH`，或把库放到调用方可加载路径；Windows 把 `gwcpp.dll` 与 exe 同目录。
