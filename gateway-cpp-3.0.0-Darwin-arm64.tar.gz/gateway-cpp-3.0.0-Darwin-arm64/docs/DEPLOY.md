# gateway-cpp 部署与配置

面向**部署/运维**。说明编译打包后的产物怎么落到目标机、路径怎么配、外部程序怎么对接。

> 核心认知：**DLL 内部不读任何写死的路径**。所有路径要么是调用时传参（`gw_open` 的字典路径、
> `gw_encode_to_file` 的输出目录），要么是 `gateway` 初始化工具的配置项。DLL 本身放哪都行。

---

## 1. 两个角色

| 产物 | 角色 | 谁用 | 依赖 |
|---|---|---|---|
| `libgwcpp.so` / `.dylib` / `gwcpp.dll` | **编码 DLL** | 外部程序 A 加载调用 | 零运行时第三方依赖 |
| `gateway`(可执行) | **字典初始化工具**（一次性） | 部署时跑一遍生成 `dict.json` | 静态链接、自包含 |

`gateway` 是静态链接的，自包含、**不需要** `.so`；只有外部程序 A 才加载 `libgwcpp`。

---

## 2. 部署目录（package.sh / CPack 解压后）

```
/opt/gateway-cpp/                    # 部署根（路径可自定）
├── lib/      libgwcpp.so              # 给程序 A 加载
├── bin/      gateway                  # 字典初始化工具
├── include/  gwcpp/capi/gwcpp_api.h   # 程序 A 编译用头文件
├── cnf/      application.yaml         # 仅 gateway 用
├── tools/    seed_import.py、upstream_json_schema.md
├── docs/     INTEGRATION.md、BUILD.md、DEPLOY.md …
├── dict.json   ← 部署时生成（不在包里）
└── data/cpurl/ ← 标识输出目录（运行时自建，路径任意）
```

---

## 3. 让程序 A 找到 DLL（DLL 无固定路径要求）

| 平台 | 方式（任选其一） |
|---|---|
| Linux | 与 A 同目录 + 链接时 `-Wl,-rpath,'$ORIGIN'`；或 `export LD_LIBRARY_PATH=/opt/gateway-cpp/lib`；或 `cp lib/libgwcpp.so /usr/local/lib && ldconfig` |
| Windows | 把 `gwcpp.dll` 放到 A 的 `.exe` **同目录**；或加入 `PATH` |
| macOS | `export DYLD_LIBRARY_PATH=/opt/gateway-cpp/lib`；或链接时 `@rpath`/`@loader_path` |

---

## 4. 配置（路径与开关）

### 字典文件 dict.json
- **程序 A**：`gw_open("/任意路径/dict.json")` —— 路径完全由调用方决定。
- **gateway 工具**：`cnf/application.yaml` 的 `store.path`，支持环境变量覆盖：
  ```yaml
  store:
    path: ${GW_DICT_FILE:./dict.json}   # 优先取环境变量 GW_DICT_FILE，缺省 ./dict.json
    mode: offline                       # offline=只用既有文件；online=从上游拉取并写入
  ```

### 标识输出目录（CPURL 数据文件）
- 是 `gw_encode_to_file` 的第 4 个参数 `out_dir`，**调用方每次传**，不存在自动创建：
  ```c
  gw_encode_to_file(ctx, json, is_total, is_monitor, "/data/cpurl/20067", &res);
  ```
- 可按企业/日期任意分目录。**文件名规则固定**：`{enterprise}-CPURL-DATA-{yyyyMMddHHmmss}{NNNN}.data`。

### application.yaml 其余字段（仅 gateway 工具用）
```yaml
network: { insecure: true }            # 自签证书内网才设 true；公网务必 false
push:     { enabled: false }           # 主动采集→编码→上报，默认关闭
heartbeat:                             # online 模式拉字典的上游与凭据
  address: https://<上游>:60006
  clientId: ...
  clientSecret: ...
collector: { enterprise: "20067" }     # 用于 /v1/zones/enter/{enterprise}
```

---

## 5. 部署步骤

```bash
# 1) 解压
mkdir -p /opt/gateway-cpp
tar xzf gateway-cpp-3.0.0-Linux-x86_64.tar.gz -C /opt/gateway-cpp --strip-components=1

# 2) 初始化字典 dict.json（二选一）
#    A) gateway 工具联网拉取（先改 cnf/application.yaml 的 heartbeat 凭据，store.mode=online）
GW_DICT_FILE=/opt/gateway-cpp/dict.json \
  /opt/gateway-cpp/bin/gateway /opt/gateway-cpp/cnf/application.yaml
#    B) 离线脚本拉取（不依赖 gateway 可执行）
export GW_CLIENT_ID=xxxx GW_CLIENT_SECRET=yyyy
python3 /opt/gateway-cpp/tools/seed_import.py \
  --base https://<上游>:60006 --enterprise 20067 --out /opt/gateway-cpp/dict.json

# 3) 让程序 A 能加载 DLL
export LD_LIBRARY_PATH=/opt/gateway-cpp/lib:$LD_LIBRARY_PATH

# 4) 程序 A 调用（伪代码）
#    gw_open("/opt/gateway-cpp/dict.json")
#    gw_encode_to_file(ctx, json, 1, 0, "/data/cpurl", &res)
#    gw_close(ctx)
```

各语言（C/C#/Python/Java）的具体调用样例见 **[`INTEGRATION.md`](INTEGRATION.md)**。

---

## 6. 字典更新（运行期热更新，不停服）

字典会变（新增企业/芯片/可用区）。更新流程：
```bash
# 重新生成 dict.json（原子替换，不会写到一半）
python3 tools/seed_import.py --base ... --enterprise 20067 --out /opt/gateway-cpp/dict.json
```
程序 A 侧调一次 `gw_reload(ctx, "/opt/gateway-cpp/dict.json")` 即可热加载新字典，
正在进行的编码不受影响（内存快照原子切换）。

---

## 7. 部署自检清单

- [ ] `dict.json` 已生成且非空（`gateway`/seed 打印各段条数；或 `jq '{d:(.dictionary|length),c:(.chips|length)}' dict.json`）。
- [ ] 程序 A 能加载 `libgwcpp`（`ldd 程序A` 能解析到 libgwcpp.so）。
- [ ] 输出目录所在分区有写权限与空间。
- [ ] 公网对接：`network.insecure: false`；内网自签才 true。
- [ ] 首调返回 `success:true`；若 `groups[].error` 提示"企业/城市/芯片不在字典内"，多半是 dict.json 与上游字典不同步 → 重新生成。

---

## 8. 常见问题

- **`gw_open` 返回 NULL**：`gw_last_error()` 会区分"文件不存在（先初始化字典）"还是"解析失败"。
- **程序 A 报找不到 libgwcpp**：见第 3 节（rpath / LD_LIBRARY_PATH / 同目录）。
- **某组 `groups[].error`**：该 (city,zone) 校验未过（企业/城市/芯片/CPU 不在字典，或 serverCatalog 非 Y 开头），其余组照常生成；不是整体失败。
- **要不要常驻进程**：不要。编码是被动按需调用；`gateway` 只在初始化/刷新字典时跑。
