# C++ 调用网关 DLL 使用手册

面向**用 C++ 调用编码网关动态库**的外部系统开发者。看完即可把"采集数据(JSON) → 算力标识文件"接进你的程序。

- 接口与多语言概览：见 [`INTEGRATION.md`](INTEGRATION.md)
- 部署与路径配置：见 [`DEPLOY.md`](DEPLOY.md)
- 输入字段定义：见 [`../tools/upstream_json_schema.md`](../tools/upstream_json_schema.md)

---

## 1. 概述

网关把编码能力以 **C ABI 动态库**（`libgwcpp.so`/`.dylib`/`gwcpp.dll`）暴露。你的 C++ 程序：
**打开字典一次 → 反复传入采集 JSON → 拿回算力标识（落盘文件或内存串）**。库**零运行时第三方依赖**、线程安全、按需调用、无需常驻。

> 为什么对外是 C 接口：C++ 的类/STL 跨动态库边界在不同编译器/运行时不兼容。
> C 接口最稳；本手册再给一层 **C++ RAII 封装**（`examples/gw_gateway.hpp`）让你像用普通对象一样用。

---

## 2. 前置：3 样东西

| 物料 | 说明 | 来源 |
|---|---|---|
| 动态库 | `libgwcpp.*` | 打包产物 `lib/` |
| 头文件 | `gwcpp/capi/gwcpp_api.h`（+ 可选 `gw_gateway.hpp`）| `include/`、`examples/` |
| 字典文件 | `dict.json` | 部署时生成，见 `DEPLOY.md` |

---

## 3. 编译与链接

要求 **C++11 及以上**（封装用到 `unique_ptr`/move；C 头本身任意 C++ 标准均可）。

### g++/clang（Linux/macOS）
```bash
g++ -std=c++17 my_app.cpp \
    -I/opt/gateway-cpp/include \      # gwcpp_api.h
    -I/opt/gateway-cpp/examples \     # gw_gateway.hpp（若用 RAII 封装）
    -L/opt/gateway-cpp/lib -lgwcpp \
    -Wl,-rpath,/opt/gateway-cpp/lib \ # 运行期定位 .so（免设 LD_LIBRARY_PATH）
    -o my_app
```

### CMake（推荐）
```cmake
cmake_minimum_required(VERSION 3.15)
project(my_app CXX)
add_executable(my_app my_app.cpp)
target_include_directories(my_app PRIVATE /opt/gateway-cpp/include /opt/gateway-cpp/examples)
target_link_directories(my_app PRIVATE /opt/gateway-cpp/lib)
target_link_libraries(my_app PRIVATE gwcpp)
set_target_properties(my_app PROPERTIES
    BUILD_RPATH   /opt/gateway-cpp/lib
    INSTALL_RPATH /opt/gateway-cpp/lib)   # 运行期定位 .so
```

### Windows（MSVC）
```bat
cl /std:c++17 /EHsc my_app.cpp /I C:\gateway-cpp\include /I C:\gateway-cpp\examples ^
   /link /LIBPATH:C:\gateway-cpp\lib gwcpp.lib
```
- 用导入库 `gwcpp.lib` 链接；运行期把 `gwcpp.dll` 放到 `my_app.exe` 同目录。
- 若**静态**链接进你的程序（而非用 DLL），在包含头文件前 `#define GWCPP_STATIC`，避免 `dllimport`。

> 运行期 DLL 怎么被找到（rpath / `LD_LIBRARY_PATH` / 同目录），详见 `DEPLOY.md` 第 3 节。

---

## 4. 推荐用法：RAII 封装

直接拷贝 `examples/gw_gateway.hpp`（header-only、零额外依赖）。它把句柄随对象生命周期 open/close、
返回串自动 `gw_free`、错误转成异常：

```cpp
#include "gw_gateway.hpp"

gw::Gateway gw("/opt/gateway-cpp/dict.json");   // 打开一次，进程内长期复用、可并发

// 编码并落盘（全量 K1，监测数据）→ 返回结果回执 JSON
std::string result = gw.encode_to_file(resource_json, /*is_total=*/true, /*is_monitor=*/false, "/data/cpurl");

// 或：只要 CPURL 串、不落盘
std::string cpurls = gw.encode_json(resource_json, /*is_total=*/true);

// 字典更新后热加载（不停服、不阻塞正在进行的编码）
gw.reload("/opt/gateway-cpp/dict.json");
```
失败抛 `gw::GatewayError`（含 `code()` 与 `gw_last_error` 详情）。对象析构自动 `gw_close`。

完整可编译示例见 **`examples/cpp_app.cpp`**（不依赖任何 JSON 库）。

---

## 5. 两种编码 API

| 方法 | 作用 | 返回 JSON |
|---|---|---|
| `encode_to_file(json, is_total, is_monitor, out_dir)` | 编码并**落盘**，按 (city,zone) 分组成一个文件 | `{success,message,path,record_count,groups:[...]}` |
| `encode_json(json, is_total)` | 编码但**不落盘**，直接拿 CPURL 串 | `{success,message,cpurls:[...]}` |

参数：
- `is_total`：`true`=全量(K1)，`false`=可用(K2)。两类需分别调用。
- `is_monitor`：`true`=监测，`false`=调度（写入文件每条记录的 `isMonitor`）。
- `out_dir`：输出目录，不存在自动创建；文件名固定 `{enterprise}-CPURL-DATA-{yyyyMMddHHmmss}{NNNN}.data`。

输入 JSON 接受三种形态（自动识别）：整包 `{code,success,data:[...]}` / 资源数组 `[...]` / 单资源对象 `{summary,servers}`。字段定义见 `upstream_json_schema.md`。

---

## 6. 解析返回 JSON

返回值是 **JSON 字符串**，用你项目里的任意 JSON 库解析。下面以 nlohmann/json 为例（**仅你的程序需要**，网关库本身不要求）：

```cpp
#include <nlohmann/json.hpp>
auto r = nlohmann::json::parse(result);
if (!r["success"].get<bool>()) {
    // 整体未成功：逐组看失败原因
    for (auto& g : r["groups"])
        if (g.contains("error"))
            std::cerr << g["city"] << "/" << g["zone"] << " 失败: " << g["error"].get<std::string>() << "\n";
} else {
    std::string path = r.value("path", "");           // 落盘文件全路径
    int n = r.value("record_count", 0);               // 写入的 (city,zone) 组数
    std::cout << "生成 " << n << " 组 → " << path << "\n";
}
```

落盘文件内容（数组，每个 (city,zone) 一个元素）：
```json
[ {"enterprise":"20067","city":"5101","zone":"Z01","isMonitor":false,
   "cpurls":["20067cp5101Z01K1/..."],
   "usage":[{"ip":"10.0.0.1","cpuUsage":33.6,"memUsage":66.8}]} ]
```

---

## 7. 错误处理（两级）

**第一级：调用返回码**（封装里转成 `GatewayError::code()`）

| 码 | 含义 | 处理 |
|---|---|---|
| `0` | 调用完成 | 再看返回 JSON 的 `success` |
| `1` | 参数为空 | 检查句柄/json/out_dir |
| `2` | 字典快照为空 | 字典未加载/为空，先初始化 dict.json |
| `3` | 输入 JSON 解析失败（语法错 / >64MB / 嵌套>128层）| 检查输入 |
| `4` | 内存分配失败 | 系统资源问题 |
| `5` | 文件写入失败 | 检查目录权限/磁盘 |
| `9` | 内部异常 | 看 `gw_last_error()` |

**第二级：业务结果**（返回码为 0 时）——看返回 JSON 的 `success` 与 `groups[].error`。
某个 (city,zone) 组校验未过（企业/城市/芯片/CPU 不在字典，或 serverCatalog 非 Y 开头）会单独失败、
记入 `groups[].error`，**不影响其它组**。

> `gw_last_error()` 是**线程局部**的，只在同线程紧接着读才有意义；封装已在异常 `what()` 里带上了。

---

## 8. 并发、生命周期、内存

- **句柄复用**：`gw::Gateway` 进程内建一次、长期持有；**不要**每次调用都构造/析构（打开字典有成本）。
- **多线程**：同一个 `Gateway` 对象可被多线程并发调用 `encode_*`（内部取只读快照，无锁）。
- **热更新**：`reload()` 原子换字典，正在进行的编码不受影响。
- **内存**：C 接口返回的 `char*` 必须 `gw_free`——封装已自动处理；你只拿到 `std::string`。
- **ABI**：库只导出 `gw_*` 符号，内部 C++/STL 符号隐藏，跨编译器安全。
- **编码**：所有字符串 **UTF-8**（JSON 含中文）。

---

## 9. 不想链接时编译期依赖？用动态加载（dlopen / LoadLibrary）

不在编译期链接 `-lgwcpp`，运行期再载入：

```cpp
#include "gwcpp/capi/gwcpp_api.h"
#include <dlfcn.h>   // Windows: <windows.h> + LoadLibrary/GetProcAddress

using OpenFn  = gw_ctx* (*)(const char*);
using EncFn   = int (*)(gw_ctx*, const char*, int, int, const char*, char**);
using FreeFn  = void (*)(char*);
using CloseFn = void (*)(gw_ctx*);

void* h = dlopen("/opt/gateway-cpp/lib/libgwcpp.so", RTLD_NOW);
auto gw_open_p  = (OpenFn) dlsym(h, "gw_open");
auto gw_enc_p   = (EncFn)  dlsym(h, "gw_encode_to_file");
auto gw_free_p  = (FreeFn) dlsym(h, "gw_free");
auto gw_close_p = (CloseFn)dlsym(h, "gw_close");

gw_ctx* ctx = gw_open_p("/opt/gateway-cpp/dict.json");
char* out = nullptr;
gw_enc_p(ctx, resource_json, 1, 0, "/data/cpurl", &out);
/* ... 用 out ... */ gw_free_p(out);
gw_close_p(ctx);
dlclose(h);
```

---

## 10. 排查清单

- 链接报 `undefined reference to gw_*` → 没 `-lgwcpp` 或 `-L` 路径不对。
- 运行报找不到 `libgwcpp.so` → rpath/`LD_LIBRARY_PATH` 没设（见 `DEPLOY.md`）。
- `gw_open` 抛异常 → `gw_last_error` 会区分"文件不存在（先初始化字典）"还是"解析失败"。
- 编码 `success:false` 且 `groups[].error` 提示"不在字典内" → dict.json 与上游字典不同步，重新生成。
- 中文乱码 → 确认输入按 UTF-8 编码传入。

---

## 11. 速查

```cpp
gw::Gateway gw(dictPath);                                  // open（抛异常）
std::string r = gw.encode_to_file(json, total, monitor, dir);  // 落盘，返回回执 JSON
std::string c = gw.encode_json(json, total);               // 不落盘，返回 cpurls JSON
gw.reload(dictPath);                                       // 热更新字典
// 析构自动 close；返回串已是 std::string（无需手动 free）
```
